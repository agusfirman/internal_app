<div class="pull-right hidden-md" >
  <b>Version</b> 1.1.0
</div>
<strong>Copyright &copy; 2016<a href="http://bromo:8080/internal/index.php"> IT Grand Family</a>.</strong> All rights reserved.